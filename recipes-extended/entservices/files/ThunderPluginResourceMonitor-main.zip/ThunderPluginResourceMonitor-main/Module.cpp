/*
 * This software is the confidential and proprietary information of
 *
 * RDK Management, LLC (RDKM) ("Confidential Information").
 *
 * Access to RDKM’s source code is conditional on the acceptance of,
 * and continued compliance with, the terms of the Software License Agreement
 * and the NondisclosureAgreement between you (the “Licensee”) and RDKM.
 * You shall not disclose this source code or such Confidential Information.
 */

#include "Module.h"

MODULE_NAME_DECLARATION(BUILD_REFERENCE)

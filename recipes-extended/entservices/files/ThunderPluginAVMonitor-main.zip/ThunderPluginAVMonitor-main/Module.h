/*
 * This software is the confidential and proprietary information of
 *
 * RDK Management, LLC (RDKM) ("Confidential Information").
 *
 * Access to RDKM’s source code is conditional on the acceptance of,
 * and continued compliance with, the terms of the Software License Agreement
 * and the NondisclosureAgreement between you (the “Licensee”) and RDKM.
 *
 * You shall not disclose this source code or such Confidential Information.
*/

#pragma once

#ifndef MODULE_NAME
#define MODULE_NAME Plugin_AVMonitor
#endif

#include <plugins/plugins.h>

#undef EXTERNAL
#define EXTERNAL
